# weather-app
 weather app react native

# to install app
npm install 

# to run
npm run start
